<?php

date_default_timezone_set('Asia/Manila');
session_start();
$server = "localhost";
$username="root";
$password= "";
$dbname="qrcodedb";

$conn = new mysqli($server,$username,$password,$dbname);

if ($conn->connect_error) {
  die("Connection failed" .$conn->connect_error);
}

// Function to assign remarks based on login time and current time
function assignRemarks($loginTime) {
  $remarks = '';
  $currentTime = time(); // Get current time in Unix timestamp format
  $lateTime = strtotime('07:30:00'); // Define the late time (e.g., 7:30 AM)

  if ($loginTime > $lateTime) {
      $remarks = 'LATE';
  } else {
      $remarks = 'PRESENT';
  }

  return $remarks;
}

if (isset($_POST['text'])){

  $text= $_POST['text'];
  $date = date ('Y-m-d');
  $time = date ('H:i:s');

  $sql = "SELECT * FROM table_attendance WHERE STUDENTID = '$text' AND LOGDATE ='$date' AND STATUS ='0'";
  $query = $conn->query($sql);
  if ($query->num_rows > 0) {
    $row = $query->fetch_assoc();
    $timein = $row['TIMEIN'];
    
    $sql = "UPDATE table_attendance SET TIMEOUT = '$time', STATUS='1' WHERE STUDENTID ='$text' AND LOGDATE='$date'";
    $query = $conn->query($sql);
    $_SESSION['success'] = 'Successfully time out';

    // Get the login time in Unix timestamp format
    $loginTime = strtotime($timein);
    $remarks = assignRemarks($loginTime);

    // Update the remarks column in the database
    $updateRemarksSql = "UPDATE table_attendance SET REMARKS = '$remarks' WHERE STUDENTID ='$text' AND LOGDATE='$date'";
    $conn->query($updateRemarksSql);

    $_SESSION['remarks'] = $remarks;

  } else {
    $sql = "INSERT INTO table_attendance(STUDENTID, TIMEIN, LOGDATE, STATUS, REMARKS) VALUES ('$text', '$time', '$date', '0', '')";
    if ($conn->query($sql) === TRUE) {
      $_SESSION['success'] = 'Successfully time in';

      // Get the login time in Unix timestamp format
      $loginTime = strtotime($time);
      $remarks = assignRemarks($loginTime);

      // Update the remarks column in the database
      $updateRemarksSql = "UPDATE table_attendance SET REMARKS = '$remarks' WHERE STUDENTID ='$text' AND LOGDATE='$date'";
      $conn->query($updateRemarksSql);

      $_SESSION['remarks'] = $remarks;
    } else {
      $_SESSION['error'] = $conn->error;
    }
  }

} else {
  $_SESSION['error'] = 'Please scan your QR code';
}

$conn->close();
header("location: index.php");
?>
