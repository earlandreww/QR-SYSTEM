<?php
// Start the session
session_start();

// Set the server, username, password, and database name
$server = "localhost";
$username = "root";
$password = "";
$dbname = "qrcodedb";

// Create a new mysqli object with the server, username, password, and database name
$conn = new mysqli($server, $username, $password, $dbname);

// If there is an error connecting to the database, die with the error message
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set the filename to be the current date
$filename = 'AttendanceRecord-'.date('Y-m-d').'.csv';

// Set the query to select all rows from the table_attendance table
$query = "SELECT * FROM table_attendance";

// Run the query and store the result
$result = mysqli_query($conn, $query);

// Initialize an array to store the data
$array = array();

// Open the file in write mode
$file = fopen($filename, "w");

// Add the header row to the csv file
$array = array("ID", "STUDENT ID", "TIME IN", "TIME OUT", "LOG DATE", "STATUS", "REMARKS");
fputcsv($file, $array);

// Loop through the result and add each row to the csv file
while ($row = mysqli_fetch_array($result)) {
    $ID = $row ['ID'];
    $STUDENTID = $row ['STUDENTID'];
    $TIMEIN = $row ['TIMEIN'];
    $TIMEOUT = $row ['TIMEOUT'];
    $LOGDATE = $row ['LOGDATE'];
    $STATUS = $row ['STATUS'];
    $REMARKS = $row ['REMARKS'];

    $array = array($ID, $STUDENTID, $TIMEIN, $TIMEOUT, $LOGDATE, $STATUS, $REMARKS);
    fputcsv($file, $array);
}

// Close the file
fclose($file);

// Set the headers to initiate a download of the csv file
header("Content-Description: File Transfer");
header("Content-Disposition: Attachment; filename=" . $filename);
header("Content-Type: application/csv");

// Read the file and send the contents to the browser
readfile($filename);

// Delete the file
unlink($filename);

// Exit the script
exit();
?>