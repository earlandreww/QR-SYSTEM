<!DOCTYPE html>
<html>
<head>
    <title>SNHS QR CODE ATTENDANCE SYSTEM</title>
    <script type="text/javascript" src="js/instascan.min.js"></script>
    <script type="text/javascript" src="js/vue.min.js"></script>
    <script type="text/javascript" src="js/adapter.min.js"></script>
    <link rel="stylesheet" href="css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-md-6">
                <h3>SNHS QR CODE ATTENDANCE SYSTEM</h3>
                <video id="preview" width="100%"></video>
                <?php
                // Display error message if it exists
                if (isset($_SESSION['error'])) {
                    echo '
                    <div class="alert alert-danger">
                        <h4> Error! </h4>
                        ' . $_SESSION['error'] . '
                    </div>
                    ';
                }

                // Display success message if it exists
                if (isset($_SESSION['success'])) {
                    echo '
                    <div class="alert alert-success">
                        <h4> Success! </h4>
                        ' . $_SESSION['success'] . '
                    </div>
                    ';
                }
                ?>
                <form action="insert1.php" method="post" class="form-horizontal">
                    <label>SCAN QR CODE</label>
                    <input type="text" name="text" id="text" readonly="" placeholder="scan qrcode" class="form-control">
                </form>
            </div>
            <div class="col-md-6">
                <h3>Attendance</h3>
                <table id="example1" class="table table-bordered">
                    <thead>
                        <tr>
                            <td>ID</td>
                            <td>STUDENT ID</td>
                            <td>TIME IN</td>
                            <td>TIME OUT</td>
                            <td>LOGDATE</td>
                            <td>STATUS</td>
                            <td>REMARKS</td>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $server = "localhost";
                        $username = "root";
                        $password = "";
                        $dbname = "qrcodedb";

                        // Create a new connection to the database
                        $conn = new mysqli($server, $username, $password, $dbname);

                        // Check for any connection errors
                        if ($conn->connect_error) {
                            die("Connection failed: " . $conn->connect_error);
                        }

                        // Set the date for today
                        $date = date('Y-m-d');

                        // Prepare the SQL query
                        $sql = "SELECT * FROM table_attendance WHERE DATE(LOGDATE)=CURDATE()";

                        // Execute the query
                        $query = $conn->query($sql);

                        // Fetch the results
                        while ($row = $query->fetch_assoc()) {
                        ?>
                            <tr>
                                <td><?php echo $row['ID']; ?></td>
                                <td><?php echo $row['STUDENTID']; ?></td>
                                <td><?php echo $row['TIMEIN']; ?></td>
                                <td><?php echo $row['TIMEOUT']; ?></td>
                                <td><?php echo $row['LOGDATE']; ?></td>
                                <td><?php echo $row['STATUS']; ?></td>
                                <td><?php echo $row['REMARKS']; ?></td>
                            </tr>
                        <?php
                        }
                        // Close the database connection
                        $conn->close();
                        ?>
                    </tbody>
                </table></div>
        </div>
        <br>
        <button type="submit" class="btn btn-success pull-right" onclick="Export()">
            <i class="fa fa-file-excel-o fa fw"></i> Export to Excel
        </button>
    </div>
    <script>
        // Initialize the scanner
        let scanner = new Instascan.Scanner({
            video: document.getElementById('preview')
        });

        // Start the scanner
        Instascan.Camera.getCameras().then(function(cameras) {
            if (cameras.length > 0) {
                scanner.start(cameras[0]);
            } else {
                alert('No cameras found');
            }
        }).catch(function(e) {
            console.error(e);
        });

        // Handle scanned codes
        scanner.addListener('scan', function(c) {
            document.getElementById('text').value = c;
            document.forms[0].submit();
        });

        // Export attendance to Excel
        function Export() {
            var conf = confirm("Please confirm if you wish to proceed in exporting the attendance in to Excel file");
            if (conf == true) {
                window.open("export.php", '_blank');
            }
        }
    </script>
</body>
</html>